﻿namespace ViewModelASPCore.Models
{
	public class SchoolViewModel
	{
		public List<Student> MyStudents { get; set; }
		public List<Teacher> MyTeachers { get; set; }
	}
}
