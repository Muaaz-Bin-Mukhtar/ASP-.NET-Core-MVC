using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Reflection;
using System.Xml.Linq;
using ViewModelASPCore.Models;

namespace ViewModelASPCore.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;

		public HomeController(ILogger<HomeController> logger)
		{
			_logger = logger;
		}

		public IActionResult Index()
		{
			List<Student> students = new List<Student>
			{
				new Student { Id = 1, Name = "Ali", Gender = "Male", Standard = 10},
				new Student { Id = 2, Name = "Ahmed", Gender = "Male", Standard = 12},
				new Student { Id = 3, Name = "Anum", Gender = "Female", Standard = 11},
				new Student { Id = 4, Name = "Anas", Gender = "Male", Standard = 10}
			};

			List<Teacher> teachers = new List<Teacher>
			{
				new Teacher { Id = 1, Name = "Sir Asghar", Qualification = "MCS", Salary = 50000},
				new Teacher { Id = 2, Name = "Sir Asad", Qualification = "BSIT", Salary = 40000},
				new Teacher { Id = 3, Name = "Mam Ayesha", Qualification = "BSCS", Salary = 45000},
				new Teacher { Id = 4, Name = "Sir Afzal", Qualification = "BSSE", Salary = 42500}
			};

			SchoolViewModel svm = new SchoolViewModel()
			{
				MyStudents = students,
				MyTeachers = teachers
			};
			return View(svm);
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
