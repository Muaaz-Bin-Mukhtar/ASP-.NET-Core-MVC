﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstASPCore.Models
{
    public class Student
    {
        [Key]
        [Required]
        public int StdId { get; set; }

        [Column("StudentName",TypeName ="varchar(100)")]
        [Required]
        public string StdName { get; set; }

        [Column("StudentGender", TypeName = "varchar(20)")]
        [Required]
        public string StdGender { get; set; }

        [Required]
        public int? StdAge { get; set; }

        [Required]
        public int? Standard { get; set; }
    }
}
