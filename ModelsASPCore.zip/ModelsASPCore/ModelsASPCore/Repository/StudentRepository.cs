﻿using ModelsASPCore.Models;

namespace ModelsASPCore.Repository
{
    public class StudentRepository : IStudent
    {
        public List<StudentModel> getAllStudents()
        {
            return DataSource();
        }

        public StudentModel getStudentById(int id)
        {
            return DataSource().Where( x => x.rollNo == id ).FirstOrDefault();
        }

        private List<StudentModel> DataSource()
        {
            return new List<StudentModel>
            {
                new StudentModel{rollNo=1,gender="Male",name="Ali",standard=11},
                new StudentModel{rollNo=2,gender="Male",name="Ahmed",standard=12},
                new StudentModel{rollNo=3,gender="Female",name="Fatima",standard=11},
                new StudentModel{rollNo=4,gender="Male",name="Faheem",standard=9},
                new StudentModel{rollNo=5,gender="Female",name="Amna",standard=12}

            };
        }
    }
}
