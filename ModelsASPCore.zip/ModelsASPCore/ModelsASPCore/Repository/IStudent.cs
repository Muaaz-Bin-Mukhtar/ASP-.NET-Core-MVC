﻿using ModelsASPCore.Models;

namespace ModelsASPCore.Repository
{
    public interface IStudent
    {
        List<StudentModel> getAllStudents();

        StudentModel getStudentById(int id);
    }
}
