﻿namespace ModelsASPCore.Models
{
    public class StudentModel
    {
        public int rollNo { get; set; }

        public string name { get; set; }

        public string gender { get; set; }

        public int standard { get; set; }
    }
}
