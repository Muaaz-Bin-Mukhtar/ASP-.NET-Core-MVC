﻿namespace StronglyTypedViewASPCore.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string EmpDesignation { get; set; }
        public int EmpSalary { get; set; } 
    }
}
