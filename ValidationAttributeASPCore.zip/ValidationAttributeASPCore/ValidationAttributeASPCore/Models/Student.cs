﻿using System.ComponentModel.DataAnnotations;

namespace ValidationAttributeASPCore.Models
{
    public class Student
    {
        [Required(ErrorMessage = "Name is required!")]
        [StringLength(5, MinimumLength = 3)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Email is required!")]
        [RegularExpression("^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$",ErrorMessage ="Invalid EMail")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Age is required!")]
        [Range(10, 20)]
        public int? Age { get; set; }

        [Required(ErrorMessage = "Password is required!")]
        [RegularExpression("(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$", ErrorMessage ="Uppercase,Lowercase,numbers,symbols,min 8 chars")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Confirm Password is required!")]
        [Compare("Password",ErrorMessage ="Both passwords must be same!")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Number is required!")]
        [RegularExpression("^((\\+92)|(0092))-{0,1}\\d{3}-{0,1}\\d{7}$|^\\d{11}$|^\\d{4}-\\d{7}$",ErrorMessage ="Invalid Number")]
        public string PNumber { get; set; }

        [Required(ErrorMessage = "Website URL is required!")]
        [Url(ErrorMessage = "Invalid URL!")]
        public string WebURL { get; set; }
    }
}
