using Microsoft.AspNetCore.Mvc;
using PartialViewASPCore.Models;
using System.Diagnostics;

namespace PartialViewASPCore.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;

		public HomeController(ILogger<HomeController> logger)
		{
			_logger = logger;
		}

		public IActionResult Index()
		{
			return View();
		}

		public IActionResult Products()
		{
			List<Product> products = new List<Product>
			{
				new Product() {Id=101, Name="Shoes", Description="Nike", Price=15000},
				new Product() {Id=102, Name="Watch", Description="Rolex", Price=150000},
				new Product() {Id=103, Name="Bottle", Description="Miniso", Price=1500}
			};
			return View(products);
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}
