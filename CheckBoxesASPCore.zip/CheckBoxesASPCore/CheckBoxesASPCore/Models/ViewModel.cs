﻿namespace CheckBoxesASPCore.Models
{
    public class ViewModel
    {
        public List<CheckBoxOption> CheckBoxes { get; set; }
        public List<string> sports { get; set; }
    }


    //public class ViewModel
    //{
    //    public bool AcceptTerms { get; set; }
    //    public string Text { get; set; }
    //}
}
