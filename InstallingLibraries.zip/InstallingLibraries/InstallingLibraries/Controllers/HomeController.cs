﻿using Microsoft.AspNetCore.Mvc;

namespace InstallingLibraries.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
