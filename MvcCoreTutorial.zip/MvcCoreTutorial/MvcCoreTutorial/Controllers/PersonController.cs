﻿using Microsoft.AspNetCore.Mvc;
using MvcCoreTutorial.Models.Domain;

namespace MvcCoreTutorial.Controllers
{
    public class PersonController : Controller
    {
        private readonly DatabaseContext _ctx;
        public PersonController(DatabaseContext ctx)
        {
            _ctx = ctx;
        }
        public IActionResult Index()
        {
            ViewBag.greeting = "Hello World!";
            ViewData["greeting2"] = "Using ViewData";
            TempData["greeting3"] = "Using TempData";
            return View();
        }

        public IActionResult AddPerson()
        {
            return View();
        }

        [HttpPost]
		public IActionResult AddPerson(Person person)
		{
            if (!ModelState.IsValid)
            {
                return View();
            }
            try
            {
                _ctx.Add(person);
                _ctx.SaveChanges();
                TempData["msg"] = "Added Successfully";
                return RedirectToAction("AddPerson");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not Add";
                return View();
            }        
		}

        public IActionResult DisplayPersons()
        {
            var persons = _ctx.Person.ToList();
            return View(persons);
        }

		public IActionResult DeletePerson(int id)
		{			
            {
                try
                {
					var person = _ctx.Person.Find(id);
					if (person != null)
                    {
                        _ctx.Person.Remove(person);
                        _ctx.SaveChanges();
                    }
				}
                catch (Exception ex )
                {

                }
                return RedirectToAction("DisplayPersons");
            }
		}

        public IActionResult EditPerson(Person person)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            try
            {
                _ctx.Update(person);
                _ctx.SaveChanges();
                TempData["msg"] = "Updated Successfully";
                return RedirectToAction("DisplayPersons");
            }
            catch (Exception ex)
            {
                TempData["msg"] = "Could not Update";
                return View();
            }
        }
    }    
}
